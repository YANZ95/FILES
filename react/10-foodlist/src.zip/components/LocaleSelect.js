import React from "react";

function LocaleSelect(props) {
  return <div></div>;
}

export default LocaleSelect;
