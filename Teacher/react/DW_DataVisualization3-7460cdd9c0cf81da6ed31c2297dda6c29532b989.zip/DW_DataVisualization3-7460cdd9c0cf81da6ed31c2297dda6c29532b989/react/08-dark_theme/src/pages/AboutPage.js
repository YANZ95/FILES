import React from 'react';
import Container from '../components/Container';

function AboutPage(props) {
  return (
    <>
      <Container>About 페이지 입니다.</Container>
    </>
  );
}

export default AboutPage;
