import React from 'react';
import Container from '../components/Container';

function MainPage(props) {
  return (
    <>
      <Container>Main 페이지 입니다.</Container>
    </>
  );
}

export default MainPage;
