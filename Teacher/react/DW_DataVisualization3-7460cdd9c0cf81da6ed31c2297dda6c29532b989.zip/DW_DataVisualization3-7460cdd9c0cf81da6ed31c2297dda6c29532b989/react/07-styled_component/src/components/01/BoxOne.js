import styled from 'styled-components';

const BoxOne = styled.div`
  background-color: red;
  width: 200px;
  height: 200px;
`;

export default BoxOne;
