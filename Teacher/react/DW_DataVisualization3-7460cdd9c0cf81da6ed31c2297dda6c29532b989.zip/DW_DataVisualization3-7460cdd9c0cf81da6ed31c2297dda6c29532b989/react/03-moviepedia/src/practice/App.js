import React from 'react';
import State from './State';

function App(props) {
  return <State />;
}

export default App;
