import styled from 'styled-components';

const BoxTwo = styled.div`
  background-color: yellow;
  width: 200px;
  height: 200px;
`;

export default BoxTwo;
