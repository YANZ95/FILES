export const CategoriesName = {
  All: '',
  Electronics: 'Electronics',
  Jewelry: 'Jewelry',
  MensClothing: "Men's clothing",
  WomensClothing: "Women's clothing",
};
